import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { CustomDirective } from './custom.directive';
import {FormsModule} from '@angular/forms';
import { SignupFormComponent } from './signup-form/signup-form.component';
import {HttpClientModule } from '@angular/common/http';
import {ApiService} from './api.service';
import { NgForm } from '@angular/forms';
import { MatDatepickerModule, MatInputModule, MatNativeDateModule } from '@angular/material';

import { ReverseStr } from './reverse-str.pipe';


@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    CustomDirective,
    SignupFormComponent,
    ReverseStr

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
