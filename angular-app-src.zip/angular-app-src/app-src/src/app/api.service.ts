import { Injectable } from '@angular/core';
import {environment} from '../environments/environment';
import { HttpClient } from '@angular/common/http';

import { map } from 'rxjs/operators';

const serviceAPI = environment.apiUrl;

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  
  constructor(private http: HttpClient) { }

  public getAllTodos() {
   return this.http
    .get<any[]>(serviceAPI+'/Employees')
    .pipe(map(data => data))
  }
}
