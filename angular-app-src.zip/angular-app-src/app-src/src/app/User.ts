export class User {
 
    id: number;
    email: string;

    pwd: string;
    confirmPwd: string;
    /*password: { 
      pwd: string;
      confirmPwd: string;
    };*/
    gender: string;
    terms: boolean;
 
    constructor(values: Object = {}) {
      //Constructor initialization
      Object.assign(this, values);
  }
 
}