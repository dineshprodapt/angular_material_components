import { Component, OnInit, OnDestroy } from '@angular/core';
import {Router, ɵROUTER_PROVIDERS} from '@angular/router';

import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

import {ApiService} from './api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[ApiService]
})

export class AppComponent implements OnInit, OnDestroy {
  title = 'app';
  myData: Array<any>;
   jsonVal: Object = {moo: 'foo', goo: {too: 'new'}};

  dateVal = new Date();
  clickme = function(){
    alert();
    this.router.navigateByUrl(['/signup-form']);
  }

  count: number = 0;
  clickCount(): void{
    this.count++;
  }

  displayChild = true;
  getUserData: any;
  displayTable = false;
  getEmployeeInfo :any;

  constructor(private http: HttpClient, private serv: ApiService){
    console.log("appcomponent: constructor");
  }
  toggle(){
    this.displayChild = !this.displayChild;
  }
  ngOnInit(){
    //this.router.navigateByUrl('./child');
    console.log("ngoninit: appcomponent");

    this.serv.getAllTodos()
    .subscribe(
      getUserData => {
        this.getUserData = getUserData;
        console.log(this.getUserData);
      }
    )

  }
  ngOnDestroy(){
    console.log("ngondestroy: appcomponent");
  }

  public getEmp(value){
    this.getEmployeeInfo = value;
    console.log(this.getEmployeeInfo);
    this.displayTable = true;


  }
 
}

