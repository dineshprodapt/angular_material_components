import { async, ComponentFixture, ComponentFixtureAutoDetect, TestBed } from '@angular/core/testing';

import { SignupFormComponent } from './signup-form.component';

import {CommonModule} from "@angular/common";
import {FormsModule} from "@angular/forms";
import {Component} from "@angular/core";
import {By} from "@angular/platform-browser";
import { HttpClient } from '@angular/common/http';


describe('SignupFormComponent', () => {
  let component: SignupFormComponent;
  let fixture: ComponentFixture<SignupFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, FormsModule, HttpClient],
      declarations: [ SignupFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should invalidate two fields that do not match', async(() => {
    //component.field1 = '12345678901234';
    //component.field2 = '12345678999999';

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();

      let field2Model = fixture.debugElement.query(By.css('input[name=field2]')).references['field2Model'];

      expect(field2Model.valid).toBe(false);
    });
  }));
});

@Component({
  template: '<form #form1="ngForm">' +
            '<input name="field1" #field1Model="ngModel" [(ngModel)]="field1">' +
            '<input name="field2" #field2Model="ngModel" [fieldMatches]="field1Model" [(ngModel)]="field2">' +
            '</form>'
})
class TestComponent {
  field1: string;
  field2: string;
}