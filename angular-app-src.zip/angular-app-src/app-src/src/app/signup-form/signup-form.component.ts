import { Component, OnInit } from '@angular/core';
import {User} from './../User';


import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';



@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent implements OnInit {

  constructor(private http: HttpClient) { }

  private gender: string[];
  private user: User;
  restItems: any;
  getItem: any;
  num: number = 1;
  restItemsUrl = 'https://reqres.in/api/users';
  getrestUrl = "https://jsonplaceholder.typicode.com/posts";
  displayid: string;
  displayTitle: string;
  collection: string[];

  postvalue: {
    "name": "morpheus",
    "job": "leader"
}
 

  ngOnInit() {
   
    this.gender = ['Male', 'Female', 'Other'];

    this.user = new User({
      email:"", 
      pwd: "" , confirm_pwd: "",
      gender: this.gender[0], terms: false}); 

    this.http
    .get<any[]>(this.getrestUrl+"/"+this.num)
    .pipe(map(data => data))
    .subscribe(
      getItem => {
        this.getItem = getItem;
        console.log(this.getItem);
        this.displayTitle = this.getItem.title;
       
      }
    )
  
  }
  public onsubmitform({ value}: { value: User}) {

    console.log(value);
    return this.http
    .post<any[]>(this.restItemsUrl, value)
    .pipe(map(data => data))
    .subscribe(
      restItems => {
        this.restItems = restItems;
        console.log(this.restItems);
        this.displayid = this.restItems.id;
      }
    )

   }
}
  

