import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Welcome Rajani';
  color='blue';
  childToggle=true;
  constructor(){
    console.log("constructor app component");
  }

  ngOnInit() {
    console.log("ngOninit app component");
  }
  ngOnDestroy(){
    console.log("onDestory app componnet");
  }
  Toggle()  {
    this.childToggle=!this.childToggle;
  }

}
