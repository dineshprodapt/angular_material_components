import { Injectable } from '@angular/core';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {map} from 'rxjs/operators';
import {User} from '.././Modules/user';

const testApi=environment.apiUrl;

@Injectable({
  providedIn: 'root'
})

export class DataServiceService {
  strUrl="https://reqres.in/api/users";
  item: any;

  constructor(private http:HttpClient) { }
  
  getUserData(value)
  {
    return this.http.post<any[]>(this.strUrl,value)
              .pipe(
                map(
                  data => data
                ))
                
  }

    getEmployeeData(){
      return this.http.get<any>(testApi+"/Employees").pipe(
        map(data => data)
      )
    }
    updateEmployeeData(eValue){
      console.log(eValue);
      //this.item = value;
      //console.log(this.item.id);
      
     
     // Working put
      /*return this.http.put<any>(testApi+"/Employees/"+eValue.id,eValue).pipe(
        map(data => data)
      )*/
     /* 
     //Working post
     return this.http.post<any>(testApi+"/Employees/",eValue).pipe(
        map(data => data)
      )*/
      
      //Working Delete
      console.log(eValue.id);
      return this.http.delete<any>(testApi+"/Employees/"+eValue.id).pipe(
        map(data => data)
      )

    }
}
