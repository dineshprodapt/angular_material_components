import { Component, OnInit } from '@angular/core';
import {User} from '../../Modules/user';
import { empty } from '../../../../node_modules/rxjs';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {DataServiceService} from '../../Service/data-service.service';

@Component({

  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  constructor(private http:HttpClient, private ds:DataServiceService) { }
  private user:User;
  private _gender:string[];
  strUrl="https://reqres.in/api/users";
  
  userData: any;

  ngOnInit() {
    this._gender=["m","f"];
    this.user=new User({
      email:"",
      password:"",
      confirmpassword:"",
      terms:false,
      gender:this._gender[0]
    });
  }
  public signupSubmit({value}: {value:User}
  ){
    console.log(value);
    this.ds.getUserData(value).subscribe(userData => {
                  this.userData = userData;
                console.log(this.userData);
              })


    // this.http.post<any[]>(this.strUrl,value)
    //           .pipe(
    //             map(
    //               data => data
    //             )
    //           ).subscribe( userData => {
    //             this.userData = userData;
    //           console.log(this.userData);
    //         }
    //           )

    // this.http.post<any[]>(this.strUrl,value)
    //           .subscribe( userData => {
    //             this.userData = userData;
    //           console.log(this.userData);
    //         }
    //           )
  }
}
