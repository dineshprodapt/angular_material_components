import { Component, OnInit } from '@angular/core';
import {DataServiceService} from '../../Service/data-service.service';

@Component({
  selector: 'app-reuse',
  templateUrl: './reuse.component.html',
  styleUrls: ['./reuse.component.css']
})
export class ReuseComponent implements OnInit {

  constructor(private ds:DataServiceService) { }

  dataVal:string= "abc";
  userData: any;
  ngOnInit() {
    this.ds.getUserData(this.dataVal)
    .subscribe( userData => {
                  this.userData = userData;
                console.log(this.userData);
              }
                )
  }

}
