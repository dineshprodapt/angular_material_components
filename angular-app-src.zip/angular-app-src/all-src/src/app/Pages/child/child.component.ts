import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit, OnDestroy {

  constructor() { 
    console.log("constructor child component");
  }

  ngOnInit() {
    console.log("ngOninit child component");
  }
  ngOnDestroy(){
    console.log("onDestory child componnet");
  }

}
