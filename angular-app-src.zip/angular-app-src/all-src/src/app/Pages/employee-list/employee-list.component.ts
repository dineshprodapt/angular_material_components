import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../../Service/data-service.service';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  displayEMPDetails = false;
  constructor(private ds: DataServiceService) { }
  tdEmpData: any;
  empDetails: any;
  eValuedata:any;
  ngOnInit() {
    this.ds.getEmployeeData()
      .subscribe(Empdata => {
        console.log(Empdata);
        this.tdEmpData = Empdata;
      })
  }


  displayDetails(eValue) {
    console.log(eValue);
    this.displayEMPDetails = true;
    this.empDetails = eValue;
  }

  updateEmpDetails(uValue) {
    this.ds.updateEmployeeData(uValue).subscribe(eValuedata => {
      this.eValuedata = eValuedata;
      console.log("eValuedata");
      console.log(this.eValuedata);
      this.ds.getEmployeeData()
      .subscribe(Empdata => {
        console.log(Empdata);
        this.tdEmpData = Empdata;
      })
      
    });

  }
}
