import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { DashboardComponent } from './dashboard/dashboard.component';

export const appRoutes: Routes = [
    { path: 'home', 
      component: HomeComponent 
    },
    {
      path: 'about',
      component: AboutComponent
    },
    { path: 'dashboard',
      component: DashboardComponent
    },
    { path: '',
    component: DashboardComponent
  }
  ];
