import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustom]'
})
export class CustomDirective {

  constructor(Element: ElementRef) {
    Element.nativeElement.innerText = 'Hi! Hello..';
   }

}
