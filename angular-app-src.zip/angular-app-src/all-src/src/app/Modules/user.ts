export class User{
    email:string;
    password:string;
    gender:string;
    confirmpassword:string;
    terms:boolean;

    constructor(values: Object={}){
        Object.assign(this, values);
    }
}