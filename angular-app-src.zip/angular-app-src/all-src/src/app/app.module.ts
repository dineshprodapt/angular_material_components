import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Pages/header/header.component';
import { CustomDirective } from './custom.directive';
import { ChildComponent } from './Pages/child/child.component';
import { SignUpComponent } from './Pages/sign-up/sign-up.component';
import {HttpClientModule} from '@angular/common/http';
import { ReuseComponent } from './Pages/reuse/reuse.component';
import {DataServiceService} from './Service/data-service.service';
import { EmployeeListComponent } from './Pages/employee-list/employee-list.component';
import {RouterModule} from '@angular/router';
import { ListComponent } from './list/list.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { appRoutes } from './routerconfig';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CustomDirective,
    ChildComponent,
    SignUpComponent,
    ReuseComponent,
    EmployeeListComponent,
    ListComponent,
    HomeComponent,
    AboutComponent,
    DashboardComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)

  ],
  providers: [DataServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
